/*
 *	version.h
 *
 *	version number
 */

char *distributor = NULL;
static char version[] = "@(#)fd.c  3.01j 07/27/19";
